#include <bits/stdc++.h>
using namespace std;

const int N = 100005;
int n;
struct Task {
    int d;
    long long v;
    bool operator<(const Task& other) const {
        return d < other.d;
    }
} tasks[N];

priority_queue<long long, vector<long long>, greater<long long>> pq;
long long total;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> tasks[i].v >> tasks[i].d;
    }
    
    sort(tasks, tasks + n);
    
    for (int i = 0; i < n; i++) {
        pq.push(tasks[i].v);
        total += tasks[i].v;
        
        if ((int)pq.size() > tasks[i].d) {
            total -= pq.top();
            pq.pop();
        }
    }
    
    cout << total << '\n';
    
    return 0;
}
