#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        // 样例
        fout << "3" << endl;
        fout << "10 1" << endl;
        fout << "200 2" << endl;
        fout << "150 2" << endl;
    }
    else if (case_num == 2)
    {
        // n=1
        fout << "1" << endl;
        fout << "100 1" << endl;
    }
    else if (case_num == 3)
    {
        // n=2, 同一天截止
        fout << "2" << endl;
        fout << "50 1" << endl;
        fout << "100 1" << endl;
    }
    else if (case_num == 4)
    {
        // 每个任务都能做
        fout << "3" << endl;
        fout << "10 1" << endl;
        fout << "20 2" << endl;
        fout << "30 3" << endl;
    }
    else if (case_num == 5)
    {
        // 只能选收益最大的
        fout << "3" << endl;
        fout << "100 1" << endl;
        fout << "200 1" << endl;
        fout << "300 1" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 小规模
        int n = 5 + (case_num - 6) * 5;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = rand() % 5 + 1;
            int v = rand() % 100 + 1;
            fout << v << " " << d << endl;
        }
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模
        int n = 100 + (case_num - 11) * 200;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = rand() % 100 + 1;
            int v = rand() % 10000 + 1;
            fout << v << " " << d << endl;
        }
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 大规模
        int n = 1000 + (case_num - 16) * 24750;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = rand() % 100000 + 1;
            int v = rand() % 1000000 + 1;
            fout << v << " " << d << endl;
        }
    }
    else if (case_num == 21)
    {
        // 全同截止时间
        int n = 1000;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            fout << (i + 1) * 10 << " 1" << endl;
        }
    }
    else if (case_num == 22)
    {
        // 截止时间递增，都能选
        int n = 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            fout << (i + 1) * 10 << " " << (i + 1) << endl;
        }
    }
    else if (case_num == 23)
    {
        // 大价值，需要 long long
        fout << "5" << endl;
        fout << "1000000000 1" << endl;
        fout << "1000000000 2" << endl;
        fout << "1000000000 2" << endl;
        fout << "1000000000 3" << endl;
        fout << "1000000000 3" << endl;
    }
    else if (case_num == 24)
    {
        // n=100000 最大规模
        int n = 100000;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << " " << (rand() % 100000 + 1) << endl;
        }
    }
    else
    {
        // 随机
        int n = rand() % 50000 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << " " << (rand() % 100000 + 1) << endl;
        }
    }
}

#endif
