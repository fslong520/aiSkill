#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int MAX_H = 1000;
const int MAX_W = 1000;
const int TEST_CASES = 25;

int H, W;
char grid[MAX_H][MAX_W + 1];

void fill_grid(char c) {
    for (int i = 0; i < H; i++) {
        for (int j = 0; j < W; j++) {
            grid[i][j] = c;
        }
        grid[i][W] = '\0';
    }
}

void set_cell(int r, int c, char ch) {
    grid[r][c] = ch;
}

void random_fill(int sr, int sc, int gr, int gc, double wall_prob = 0.2) {
    const char cells[] = {'.', '.', '.', '.', '.', 'o', 'x'};
    for (int i = 0; i < H; i++) {
        for (int j = 0; j < W; j++) {
            if ((i == sr && j == sc) || (i == gr && j == gc)) continue;
            if (rand() % 100 < wall_prob * 100) {
                grid[i][j] = '#';
            } else {
                grid[i][j] = cells[rand() % 7];
            }
        }
    }
}

void test(int case_id, ofstream& fout) {
    switch(case_id) {
        // Case 1: Sample 1
        case 1:
            H = 3; W = 4;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(0, 2, 'o');
            set_cell(1, 1, '#'); set_cell(1, 2, 'x');
            set_cell(2, 2, 'o'); set_cell(2, 3, 'G');
            break;

        // Case 2: Sample 2
        case 2:
            H = 3; W = 3;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(0, 2, 'o');
            set_cell(1, 0, '#'); set_cell(1, 1, 'x'); set_cell(1, 2, '#');
            set_cell(2, 0, 'o'); set_cell(2, 2, 'G');
            break;

        // Case 3: Sample 3
        case 3:
            H = 5; W = 5;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(4, 4, 'G');
            for (int i = 1; i <= 3; i++) {
                set_cell(i, 1, '#'); set_cell(i, 3, '#');
            }
            set_cell(1, 2, '#'); set_cell(3, 2, '#');
            break;

        // Case 4-6: Small grids
        case 4: case 5: case 6:
            H = (case_id - 3) * 3 + 3; W = (case_id - 3) * 2 + 4;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(H - 1, W - 1, 'G');
            set_cell(1, 1, 'o'); set_cell(1, 2, 'o');
            set_cell(2, 0, 'x');
            break;

        // Case 7-10: Medium grids
        case 7: case 8: case 9: case 10:
            H = (case_id - 6) * 20 + 30; W = (case_id - 6) * 15 + 25;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(H - 1, W - 1, 'G');
            for (int i = 1; i < H - 1; i++) {
                for (int j = 1; j < W - 1; j++) {
                    if (rand() % 10 == 0) set_cell(i, j, '#');
                    else if (rand() % 8 == 0) set_cell(i, j, rand() % 2 == 0 ? 'o' : 'x');
                }
            }
            break;

        // Case 11-15: Larger grids, mostly dots
        case 11: case 12: case 13: case 14: case 15:
            H = (case_id - 10) * 40 + 100; W = (case_id - 10) * 40 + 100;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(H - 1, W - 1, 'G');
            for (int i = 1; i < H - 1; i++) {
                for (int j = 1; j < W - 1; j++) {
                    if (rand() % 20 == 0) set_cell(i, j, '#');
                }
            }
            break;

        // Case 16-18: All dots (easy path)
        case 16: case 17: case 18:
            H = (case_id - 15) * 50 + 100; W = (case_id - 15) * 50 + 100;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(H - 1, W - 1, 'G');
            break;

        // Case 19-20: Many walls
        case 19: case 20:
            H = (case_id - 18) * 50 + 200; W = (case_id - 18) * 50 + 200;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(H - 1, W - 1, 'G');
            for (int i = 1; i < H - 1; i++) {
                for (int j = 1; j < W - 1; j++) {
                    if (rand() % 5 == 0) set_cell(i, j, '#');
                    else if (rand() % 6 == 0) set_cell(i, j, rand() % 2 == 0 ? 'o' : 'x');
                }
            }
            break;

        // Case 21-25: Stress test with many o/x
        case 21: case 22: case 23: case 24: case 25:
            H = (case_id - 20) * 60 + 200; W = (case_id - 20) * 60 + 200;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(H - 1, W - 1, 'G');
            for (int i = 1; i < H - 1; i++) {
                for (int j = 1; j < W - 1; j++) {
                    if (rand() % 15 == 0) set_cell(i, j, '#');
                    else if (rand() % 3 == 0) set_cell(i, j, rand() % 2 == 0 ? 'o' : 'x');
                }
            }
            break;

        default:
            H = 3; W = 3;
            fill_grid('.');
            set_cell(0, 0, 'S'); set_cell(2, 2, 'G');
            break;
    }

    fout << H << " " << W << "\n";
    for (int i = 0; i < H; i++) {
        fout << grid[i] << "\n";
    }
}

#endif
