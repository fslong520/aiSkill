#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
#include <iomanip>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        // 样例1
        fout << "3 2" << endl;
        fout << "1 95" << endl;
        fout << "2 90" << endl;
        fout << "3 85" << endl;
    }
    else if (case_num == 2)
    {
        // 样例2：只有1个学生
        fout << "1 1" << endl;
        fout << "101 100.00" << endl;
    }
    else if (case_num == 3)
    {
        // 小规模：5个学生，求第3名
        fout << "5 3" << endl;
        for(int i=0; i<5; i++) fout << (i+1) << " " << fixed << setprecision(1) << (90.0 - i*2.5) << endl;
    }
    else if (case_num == 4)
    {
        // 小规模：10个学生，求第1名
        fout << "10 1" << endl;
        for(int i=0; i<10; i++) fout << (100+i) << " " << fixed << setprecision(1) << (80.0 + rand()%20) << endl;
    }
    else if (case_num == 5)
    {
        // 小规模：10个学生，求第10名
        fout << "10 10" << endl;
        for(int i=0; i<10; i++) fout << (200+i) << " " << fixed << setprecision(1) << (70.0 + rand()%20) << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 中等规模：N=50, 随机查询
        int n = 50;
        int k = rand()%n + 1;
        fout << n << " " << k << endl;
        for(int i=0; i<n; i++) fout << (1000+i) << " " << fixed << setprecision(2) << (60.0 + (rand()%4000)/100.0) << endl;
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模：N=80, 成绩相近
        int n = 80;
        int k = rand()%n + 1;
        fout << n << " " << k << endl;
        for(int i=0; i<n; i++) fout << (2000+i) << " " << fixed << setprecision(2) << (85.0 + (rand()%100)/100.0) << endl;
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 最大规模边界：N=100, 极端成绩
        int n = 100;
        int k = rand()%n + 1;
        fout << n << " " << k << endl;
        for(int i=0; i<n; i++) fout << (3000+i) << " " << fixed << setprecision(2) << (0.0 + (rand()%10000)/100.0) << endl;
    }
    else if (case_num >= 21 && case_num <= 25)
    {
        // 随机测试：N=1~100
        int n = rand()%100 + 1;
        int k = rand()%n + 1;
        fout << n << " " << k << endl;
        for(int i=0; i<n; i++) fout << (4000+i) << " " << fixed << setprecision(2) << (50.0 + (rand()%5000)/100.0) << endl;
    }
}

#endif
