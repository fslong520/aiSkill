#include <bits/stdc++.h>
using namespace std;

// 学生结构体
struct Student {
    int id;      // 学号
    double score; // 成绩
};

// 比较函数：按成绩从高到低排序
bool cmp(Student a, Student b) {
    return a.score > b.score;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, k;
    if (!(cin >> n >> k)) return 0;
    
    vector<Student> stu(n);
    for (int i = 0; i < n; ++i) {
        cin >> stu[i].id >> stu[i].score;
    }
    
    // 排序
    sort(stu.begin(), stu.end(), cmp);
    
    // 输出第 k 名（注意数组下标从 0 开始，所以是 k-1）
    // 保留两位小数输出成绩
    cout << stu[k - 1].id << " " << fixed << setprecision(2) << stu[k - 1].score << endl;
    
    return 0;
}
