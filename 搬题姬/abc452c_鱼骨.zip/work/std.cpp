#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    cin >> N;

    vector<int> A(N), B(N);
    for (int i = 0; i < N; i++) {
        cin >> A[i] >> B[i];
        B[i]--; // 转换为 0-indexed
    }

    int M;
    cin >> M;
    vector<string> S(M);
    for (int i = 0; i < M; i++) {
        cin >> S[i];
    }

    // 预处理：对于每个 (长度, 位置, 字符)，记录是否存在这样的字符串
    // cnt[len][pos][char] = 是否存在长度为 len，第 pos 个字符为 char 的字符串
    set<tuple<int, int, char>> valid;

    for (const auto& s : S) {
        int len = s.size();
        for (int pos = 0; pos < len; pos++) {
            valid.insert({len, pos, s[pos]});
        }
    }

    // 对每个候选字符串判断
    for (const auto& spine : S) {
        if ((int)spine.size() != N) {
            cout << "No\n";
            continue;
        }

        bool ok = true;
        for (int i = 0; i < N; i++) {
            // 肋骨 i 需要：长度 A[i]，第 B[i] 个字符是 spine[i]
            if (!valid.count({A[i], B[i], spine[i]})) {
                ok = false;
                break;
            }
        }

        cout << (ok ? "Yes" : "No") << "\n";
    }

    return 0;
}
