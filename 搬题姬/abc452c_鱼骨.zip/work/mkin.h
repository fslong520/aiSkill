#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout) {
    // 简化测试：生成合理的小规模测试数据

    if (case_num == 1) {
        // 样例1
        fout << "5\n";
        fout << "5 3\n";
        fout << "5 2\n";
        fout << "4 1\n";
        fout << "5 1\n";
        fout << "3 2\n";
        fout << "8\n";
        fout << "retro\n";
        fout << "chris\n";
        fout << "itchy\n";
        fout << "tuna\n";
        fout << "crab\n";
        fout << "rock\n";
        fout << "cod\n";
        fout << "ash\n";
    }
    else if (case_num == 2) {
        // 样例2
        fout << "5\n";
        fout << "5 1\n";
        fout << "5 2\n";
        fout << "5 3\n";
        fout << "5 4\n";
        fout << "5 5\n";
        fout << "8\n";
        fout << "retro\n";
        fout << "chris\n";
        fout << "itchy\n";
        fout << "tuna\n";
        fout << "crab\n";
        fout << "rock\n";
        fout << "cod\n";
        fout << "ash\n";
    }
    else if (case_num == 3) {
        // 最小N=1
        fout << "1\n";
        fout << "3 2\n";
        fout << "3\n";
        fout << "abc\n";
        fout << "def\n";
        fout << "ghi\n";
    }
    else if (case_num == 4) {
        // N=1, 脊椎长度匹配
        fout << "1\n";
        fout << "2 1\n";
        fout << "2\n";
        fout << "ab\n";
        fout << "cd\n";
    }
    else if (case_num == 5) {
        // N=2
        fout << "2\n";
        fout << "3 1\n";
        fout << "3 2\n";
        fout << "4\n";
        fout << "ab\n";
        fout << "abc\n";
        fout << "bcd\n";
        fout << "cde\n";
    }
    else if (case_num == 6) {
        // N=3
        fout << "3\n";
        fout << "2 1\n";
        fout << "2 2\n";
        fout << "2 1\n";
        fout << "3\n";
        fout << "abc\n";
        fout << "ab\n";
        fout << "cd\n";
    }
    else if (case_num == 7) {
        // N=3, 多个候选
        fout << "3\n";
        fout << "3 1\n";
        fout << "3 2\n";
        fout << "3 3\n";
        fout << "5\n";
        fout << "abc\n";
        fout << "aaa\n";
        fout << "bbb\n";
        fout << "ccc\n";
        fout << "xyz\n";
    }
    else if (case_num == 8) {
        // N=4
        fout << "4\n";
        fout << "4 1\n";
        fout << "4 2\n";
        fout << "4 3\n";
        fout << "4 4\n";
        fout << "5\n";
        fout << "abcd\n";
        fout << "aaaa\n";
        fout << "bbbb\n";
        fout << "cccc\n";
        fout << "dddd\n";
    }
    else if (case_num == 9) {
        // 边界: 所有肋骨长度为1
        fout << "3\n";
        fout << "1 1\n";
        fout << "1 1\n";
        fout << "1 1\n";
        fout << "4\n";
        fout << "abc\n";
        fout << "a\n";
        fout << "b\n";
        fout << "c\n";
    }
    else if (case_num == 10) {
        // N=5
        fout << "5\n";
        fout << "5 1\n";
        fout << "4 2\n";
        fout << "3 3\n";
        fout << "2 1\n";
        fout << "1 1\n";
        fout << "6\n";
        fout << "abcde\n";
        fout << "axxxx\n";
        fout << "xbxx\n";
        fout << "xxc\n";
        fout << "dx\n";
        fout << "e\n";
    }
    else if (case_num >= 11 && case_num <= 15) {
        // 随机N=2-5
        int n = case_num - 9;
        fout << n << "\n";
        for (int i = 0; i < n; i++) {
            fout << "5 " << (i + 1) << "\n";
        }
        fout << "5\n";
        fout << "abcde\n";
        fout << "fghij\n";
        fout << "klmno\n";
        fout << "pqrst\n";
        fout << "uvwxy\n";
    }
    else if (case_num >= 16 && case_num <= 20) {
        // 测试长度不匹配的情况
        int n = case_num - 14;
        fout << n << "\n";
        for (int i = 0; i < n; i++) {
            fout << (i + 3) << " 1\n";
        }
        fout << "6\n";
        fout << "ab\n";
        fout << "abc\n";
        fout << "abcd\n";
        fout << "abcde\n";
        fout << "abcdef\n";
        fout << "abcdefg\n";
    }
    else {
        // N=10 最大
        fout << "10\n";
        for (int i = 0; i < 10; i++) {
            fout << (i + 1) << " " << ((i % (i + 1)) + 1) << "\n";
        }
        fout << "10\n";
        fout << "abcdefghij\n";
        fout << "a\n";
        fout << "ab\n";
        fout << "abc\n";
        fout << "abcd\n";
        fout << "abcde\n";
        fout << "abcdef\n";
        fout << "abcdefg\n";
        fout << "abcdefgh\n";
        fout << "abcdefghi\n";
    }
}

#endif
