#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        // 样例1
        fout << "3" << endl;
        fout << "3 10 20 30" << endl;
        fout << "2 50 50" << endl;
        fout << "4 5 5 5 5" << endl;
    }
    else if (case_num == 2)
    {
        // 样例2：1个礼盒
        fout << "1" << endl;
        fout << "2 100 200" << endl;
    }
    else if (case_num == 3)
    {
        // 样例3：总价相同，按数量
        fout << "2" << endl;
        fout << "3 10 10 10" << endl;
        fout << "2 15 15" << endl;
    }
    else if (case_num == 4)
    {
        // 样例4：总价相同，数量相同
        fout << "2" << endl;
        fout << "2 10 20" << endl;
        fout << "2 15 15" << endl;
    }
    else if (case_num == 5)
    {
        // 小规模
        fout << "3" << endl;
        fout << "1 100" << endl;
        fout << "1 50" << endl;
        fout << "1 200" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 中等规模：N=10~50
        int n = 10 + (case_num - 6) * 10;
        fout << n << endl;
        for(int i=0; i<n; i++) {
            int k = rand()%10 + 1;
            fout << k;
            for(int j=0; j<k; j++) fout << " " << (rand()%100 + 1);
            fout << endl;
        }
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模：N=100，大总价
        int n = 100;
        fout << n << endl;
        for(int i=0; i<n; i++) {
            int k = rand()%50 + 1;
            fout << k;
            for(int j=0; j<k; j++) fout << " " << (rand()%1000 + 1);
            fout << endl;
        }
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 大规模边界：N=1000
        int n = 1000;
        fout << n << endl;
        for(int i=0; i<n; i++) {
            int k = rand()%10 + 1;
            fout << k;
            for(int j=0; j<k; j++) fout << " " << (rand()%1000 + 1);
            fout << endl;
        }
    }
    else if (case_num >= 21 && case_num <= 25)
    {
        // 随机测试：N=1~1000
        int n = rand()%1000 + 1;
        fout << n << endl;
        for(int i=0; i<n; i++) {
            int k = rand()%20 + 1;
            fout << k;
            for(int j=0; j<k; j++) fout << " " << (rand()%500 + 1);
            fout << endl;
        }
    }
}

#endif
