#include <bits/stdc++.h>
using namespace std;

struct GiftBox {
    int id;
    int count;
    long long total_price;
    vector<int> items;
};

// 比较函数
bool cmp(GiftBox a, GiftBox b) {
    if (a.total_price != b.total_price) {
        return a.total_price > b.total_price; // 总价降序
    }
    return a.count > b.count; // 数量降序
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n;
    if (!(cin >> n)) return 0;
    
    vector<GiftBox> boxes(n);
    for (int i = 0; i < n; ++i) {
        boxes[i].id = i;
        cin >> boxes[i].count;
        boxes[i].items.resize(boxes[i].count);
        boxes[i].total_price = 0;
        for (int j = 0; j < boxes[i].count; ++j) {
            cin >> boxes[i].items[j];
            boxes[i].total_price += boxes[i].items[j];
        }
    }
    
    sort(boxes.begin(), boxes.end(), cmp);
    
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < boxes[i].count; ++j) {
            cout << boxes[i].items[j] << (j == boxes[i].count - 1 ? "" : " ");
        }
        cout << endl;
    }
    
    return 0;
}
