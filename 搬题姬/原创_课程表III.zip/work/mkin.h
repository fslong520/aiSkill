#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        fout << "3" << endl;
        fout << "100 200" << endl;
        fout << "200 1300" << endl;
        fout << "1000 1250" << endl;
    }
    else if (case_num == 2)
    {
        // n=1
        fout << "1" << endl;
        fout << "5 10" << endl;
    }
    else if (case_num == 3)
    {
        // 只能选一门
        fout << "3" << endl;
        fout << "10 10" << endl;
        fout << "10 10" << endl;
        fout << "10 10" << endl;
    }
    else if (case_num == 4)
    {
        // 都能选
        fout << "3" << endl;
        fout << "1 10" << endl;
        fout << "2 20" << endl;
        fout << "3 30" << endl;
    }
    else if (case_num == 5)
    {
        // 需要反悔
        fout << "4" << endl;
        fout << "5 5" << endl;
        fout << "3 6" << endl;
        fout << "4 6" << endl;
        fout << "2 7" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 小规模
        int n = 5 + (case_num - 6) * 5;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = rand() % 10 + 1;
            int last = d + rand() % 20 + 1;
            fout << d << " " << last << endl;
        }
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模
        int n = 100 + (case_num - 11) * 200;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = rand() % 1000 + 1;
            int last = d + rand() % 10000 + 1;
            fout << d << " " << last << endl;
        }
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 大规模
        int n = 1000 + (case_num - 16) * 24750;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = rand() % 10000 + 1;
            int last = d + rand() % 1000000 + 1;
            fout << d << " " << last << endl;
        }
    }
    else if (case_num == 21)
    {
        // 所有课程截止时间相同
        int n = 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            fout << (i + 1) << " 1000" << endl;
        }
    }
    else if (case_num == 22)
    {
        // 递增截止时间，都能选
        int n = 100;
        int cur = 0;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = i + 1;
            cur += d;
            fout << d << " " << (cur + 100) << endl;
        }
    }
    else if (case_num == 23)
    {
        // 大数值
        fout << "3" << endl;
        fout << "1000000000 1000000000" << endl;
        fout << "1 1000000000" << endl;
        fout << "1 1000000000" << endl;
    }
    else if (case_num == 24)
    {
        // n=100000
        int n = 100000;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = rand() % 10000 + 1;
            int last = d + rand() % 1000000 + 1;
            fout << d << " " << last << endl;
        }
    }
    else
    {
        int n = rand() % 50000 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int d = rand() % 10000 + 1;
            int last = d + rand() % 1000000 + 1;
            fout << d << " " << last << endl;
        }
    }
}

#endif
