#include <bits/stdc++.h>
using namespace std;

const int N = 100005;
int n;
struct Course {
    int d, last;
    bool operator<(const Course& other) const {
        return last < other.last;
    }
} courses[N];

priority_queue<int> pq;  // 大根堆
int time_sum;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> courses[i].d >> courses[i].last;
    }
    
    sort(courses, courses + n);
    
    for (int i = 0; i < n; i++) {
        if (time_sum + courses[i].d <= courses[i].last) {
            time_sum += courses[i].d;
            pq.push(courses[i].d);
        } else if (!pq.empty() && pq.top() > courses[i].d) {
            time_sum -= pq.top() - courses[i].d;
            pq.pop();
            pq.push(courses[i].d);
        }
    }
    
    cout << pq.size() << '\n';
    
    return 0;
}
