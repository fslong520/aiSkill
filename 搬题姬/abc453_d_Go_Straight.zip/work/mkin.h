#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
#include "mkin.h"

using namespace std;

const char grid_chars[4] = {'.', 'o', 'x', '#'};

void place_SG(vector<string>& grid, int& sr, int& sc, int& gr, int& gc, int H, int W) {
    // 确保 S 和 G 不在同一位置
    sr = rnd.next(0, H - 1);
    sc = rnd.next(0, W - 1);
    do {
        gr = rnd.next(0, H - 1);
        gc = rnd.next(0, W - 1);
    } while (gr == sr && gc == sc);
    
    grid[sr][sc] = 'S';
    grid[gr][gc] = 'G';
}

void test() {
    // 第1-2组: 样例
    {
        int H = 4, W = 6;
        printf("%d %d\n", H, W);
        vector<string> grid = {"S....G", "##.###", "#o#o#x", "..#x.."};
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
    {
        int H = 4, W = 7;
        printf("%d %d\n", H, W);
        vector<string> grid = {"...#...", ".#.#.#.", ".SoGxG.", ".#.#.#."};
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
    
    // 第3-5组: 小规模 (2<=H,W<=10)
    for (int t = 0; t < 3; t++) {
        int H = rnd.next(2, 10);
        int W = rnd.next(2, 10);
        vector<string> grid(H, string(W, '.'));
        int sr, sc, gr, gc;
        place_SG(grid, sr, sc, gr, gc, H, W);
        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                if (grid[i][j] == '.') {
                    int r = rnd.next(0, 100);
                    if (r < 15) grid[i][j] = '#';
                    else if (r < 20) grid[i][j] = 'o';
                    else if (r < 25) grid[i][j] = 'x';
                }
            }
        }
        printf("%d %d\n", H, W);
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
    
    // 第6-10组: 中等规模 (H,W <= 100)
    for (int t = 0; t < 5; t++) {
        int H = rnd.next(10, 100);
        int W = rnd.next(10, 100);
        vector<string> grid(H, string(W, '.'));
        int sr, sc, gr, gc;
        place_SG(grid, sr, sc, gr, gc, H, W);
        int wall_pct = rnd.next(10, 30);
        int o_pct = rnd.next(5, 15);
        int x_pct = rnd.next(5, 15);
        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                if (grid[i][j] == '.') {
                    int r = rnd.next(0, 100);
                    if (r < wall_pct) grid[i][j] = '#';
                    else if (r < wall_pct + o_pct) grid[i][j] = 'o';
                    else if (r < wall_pct + o_pct + x_pct) grid[i][j] = 'x';
                }
            }
        }
        printf("%d %d\n", H, W);
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
    
    // 第11-15组: 大规模 (H,W <= 1000)
    for (int t = 0; t < 5; t++) {
        int H = rnd.next(500, 1000);
        int W = rnd.next(500, 1000);
        vector<string> grid(H, string(W, '.'));
        int sr, sc, gr, gc;
        place_SG(grid, sr, sc, gr, gc, H, W);
        int wall_pct = rnd.next(10, 25);
        int special_pct = rnd.next(5, 10);
        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                if (grid[i][j] == '.') {
                    int r = rnd.next(0, 100);
                    if (r < wall_pct) grid[i][j] = '#';
                    else if (r < wall_pct + special_pct) grid[i][j] = rnd.next(0, 2) == 0 ? 'o' : 'x';
                }
            }
        }
        printf("%d %d\n", H, W);
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
    
    // 第16-18组: 边界情况 - S 和 G 相邻
    for (int t = 0; t < 3; t++) {
        int H = rnd.next(2, 50);
        int W = rnd.next(2, 50);
        vector<string> grid(H, string(W, '.'));
        sr = rnd.next(0, H - 1);
        sc = rnd.next(0, W - 1);
        grid[sr][sc] = 'S';
        int dr[4] = {-1, 1, 0, 0}, dc[4] = {0, 0, -1, 1};
        int d = rnd.next(0, 3);
        int gr = sr + dr[d], gc = sc + dc[d];
        if (gr < 0 || gr >= H || gc < 0 || gc >= W) {
            d = (d + 2) % 4;
            gr = sr + dr[d]; gc = sc + dc[d];
        }
        if (gr >= 0 && gr < H && gc >= 0 && gc < W) {
            grid[gr][gc] = 'G';
            for (int i = 0; i < H; i++) {
                for (int j = 0; j < W; j++) {
                    if (grid[i][j] == '.' && rnd.next(0, 100) < 20) grid[i][j] = '#';
                }
            }
        }
        printf("%d %d\n", H, W);
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
    
    // 第19-20组: 全部是 o 或 x 的特殊路径
    for (int t = 0; t < 2; t++) {
        int H = rnd.next(5, 50);
        int W = rnd.next(5, 50);
        vector<string> grid(H, string(W, rnd.next(0, 2) == 0 ? 'o' : 'x'));
        int sr, sc, gr, gc;
        place_SG(grid, sr, sc, gr, gc, H, W);
        printf("%d %d\n", H, W);
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
    
    // 第21-23组: 迷宫式布局
    for (int t = 0; t < 3; t++) {
        int H = rnd.next(10, 50);
        int W = rnd.next(10, 50);
        vector<string> grid(H, string(W, '#'));
        int sr, sc, gr, gc;
        place_SG(grid, sr, sc, gr, gc, H, W);
        // 用 DFS 生成路径
        stack<pair<int,int>> st;
        st.push({sr, sc});
        while (!st.empty()) {
            auto [r, c] = st.top();
            vector<pair<int,int>> dirs = {{-1,0},{1,0},{0,-1},{0,1}};
            shuffle(dirs.begin(), dirs.end(), mt19937(rnd.next(1, 1e9)));
            bool moved = false;
            for (auto [dr, dc] : dirs) {
                int nr = r + dr, nc = c + dc;
                if (nr >= 0 && nr < H && nc >= 0 && nc < W && grid[nr][nc] == '#') {
                    grid[nr][nc] = '.';
                    st.push({nr, nc});
                    moved = true;
                    break;
                }
            }
            if (!moved) st.pop();
        }
        // 随机添加 o/x
        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                if (grid[i][j] == '.' && grid[i][j] != 'S' && grid[i][j] != 'G') {
                    if (rnd.next(0, 100) < 10) grid[i][j] = rnd.next(0, 2) == 0 ? 'o' : 'x';
                }
            }
        }
        printf("%d %d\n", H, W);
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
    
    // 第24-25组: 压力测试 - 大面积开放区域
    for (int t = 0; t < 2; t++) {
        int H = 1000, W = 1000;
        printf("%d %d\n", H, W);
        vector<string> grid(H, string(W, '.'));
        int sr = rnd.next(0, H/2 - 1);
        int sc = rnd.next(0, W/2 - 1);
        int gr = rnd.next(H/2, H - 1);
        int gc = rnd.next(W/2, W - 1);
        grid[sr][sc] = 'S';
        grid[gr][gc] = 'G';
        // 少量障碍
        for (int k = 0; k < 50000; k++) {
            int r = rnd.next(0, H - 1);
            int c = rnd.next(0, W - 1);
            if (grid[r][c] == '.') grid[r][c] = '#';
        }
        // 少量 o/x
        for (int k = 0; k < 10000; k++) {
            int r = rnd.next(0, H - 1);
            int c = rnd.next(0, W - 1);
            if (grid[r][c] == '.') grid[r][c] = rnd.next(0, 2) == 0 ? 'o' : 'x';
        }
        for (int i = 0; i < H; i++) printf("%s\n", grid[i].c_str());
    }
}

#endif // MKIN_H
