#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        // 样例1
        fout << "5 10" << endl;
        fout << "3 14 10 7 10" << endl;
    }
    else if (case_num == 2)
    {
        // 样例2
        fout << "3 5" << endl;
        fout << "8 12 6" << endl;
    }
    else if (case_num == 3)
    {
        // 样例3
        fout << "10 50" << endl;
        fout << "45 60 50 30 50 70 48 55 49 50" << endl;
    }
    else if (case_num == 4)
    {
        // 样例4
        fout << "20 1000000000" << endl;
        fout << "999999999 1000000000 999999998 500000000 1000000000 999999997 800000000 1000000000 999999999 600000000 700000000 900000000 1000000000 999999996 850000000 1000000000 750000000 950000000 999999999 1000000000" << endl;
    }
    else if (case_num == 5)
    {
        // 样例5
        fout << "1 1" << endl;
        fout << "1" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 小规模测试：N=10~50，L较小
        int n = 10 + (case_num - 6) * 10;
        long long l = rand() % 100 + 1;
        fout << n << " " << l << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 200 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模测试：N=100~1000
        int n = 100 + (case_num - 11) * 225;
        long long l = rand() % 10000 + 1;
        fout << n << " " << l << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 20000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 大规模测试：N=10000~100000
        int n = 10000 + (case_num - 16) * 22500;
        long long l = rand() % 1000000000 + 1;
        fout << n << " " << l << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 21)
    {
        // 边界情况：L=1，所有D_i=1
        int n = 1000;
        fout << n << " 1" << endl;
        for (int i = 0; i < n; i++) {
            fout << "1" << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 22)
    {
        // 边界情况：L=1，所有D_i=2（无解）
        int n = 1000;
        fout << n << " 1" << endl;
        for (int i = 0; i < n; i++) {
            fout << "2" << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 23)
    {
        // 边界情况：L=10^9，所有D_i=10^9
        int n = 5000;
        fout << n << " 1000000000" << endl;
        for (int i = 0; i < n; i++) {
            fout << "1000000000" << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 24)
    {
        // 最大规模测试：N=200000
        int n = 200000;
        long long l = 1000000000;
        fout << n << " " << l << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else
    {
        // 随机压力测试
        int n = rand() % 100000 + 1;
        long long l = rand() % 1000000000 + 1;
        fout << n << " " << l << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
}

#endif
