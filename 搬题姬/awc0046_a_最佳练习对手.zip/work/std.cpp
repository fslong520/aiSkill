#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    long long l;
    cin >> n >> l;

    int ans = -1;       // 答案，初始为 -1（无解）
    long long mx = -1;  // 能满足条件的最大 D_i

    for (int i = 1; i <= n; i++) {
        long long d;
        cin >> d;
        if (d <= l && d > mx) {
            // 高桥能战胜，且实力值比之前记录的最大值更大
            mx = d;
            ans = i;
        }
    }

    cout << ans << "\n";

    return 0;
}
