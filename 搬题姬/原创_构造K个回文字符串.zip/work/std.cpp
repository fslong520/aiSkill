#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    cin >> s;
    int k;
    cin >> k;

    int n = s.size();

    // 统计每个字符出现次数
    vector<int> cnt(26, 0);
    for (char c : s) {
        cnt[c - 'a']++;
    }

    // 统计出现奇数次的字符个数
    int odd_count = 0;
    for (int i = 0; i < 26; i++) {
        if (cnt[i] % 2 == 1) {
            odd_count++;
        }
    }

    // 判断条件：
    // 1. k 不能超过字符串长度（每个回文串至少1个字符）
    // 2. 奇数次字符个数不能超过k（每个回文串最多1个奇数次字符）
    if (k <= n && odd_count <= k) {
        cout << "Yes\n";
    } else {
        cout << "No\n";
    }

    return 0;
}
