#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout) {
    if (case_num == 1) {
        // 样例1
        fout << "annabelle\n";
        fout << "2\n";
    }
    else if (case_num == 2) {
        // 样例2
        fout << "leetcode\n";
        fout << "3\n";
    }
    else if (case_num == 3) {
        // 最小数据：单字符
        fout << "a\n";
        fout << "1\n";
    }
    else if (case_num == 4) {
        // 单字符，k超过长度
        fout << "a\n";
        fout << "2\n";
    }
    else if (case_num == 5) {
        // 所有字符都相同（全偶数次）
        fout << "aaaa\n";
        fout << "2\n";
    }
    else if (case_num == 6) {
        // 所有字符都相同，k=1
        fout << "aaaa\n";
        fout << "1\n";
    }
    else if (case_num == 7) {
        // 每个字符都只出现一次（全奇数次）
        fout << "abcdef\n";
        fout << "6\n";
    }
    else if (case_num == 8) {
        // 全奇数次，k不够
        fout << "abcdef\n";
        fout << "3\n";
    }
    else if (case_num == 9) {
        // k=1，本身是回文
        fout << "aba\n";
        fout << "1\n";
    }
    else if (case_num == 10) {
        // k=1，本身不是回文
        fout << "ab\n";
        fout << "1\n";
    }
    else if (case_num == 11) {
        // k等于字符串长度
        fout << "abc\n";
        fout << "3\n";
    }
    else if (case_num == 12) {
        // k超过字符串长度
        fout << "ab\n";
        fout << "5\n";
    }
    else if (case_num == 13) {
        // 大规模：全偶数次
        string s;
        for (int i = 0; i < 50000; i++) s += "ab";
        fout << s << "\n";
        fout << "1\n";
    }
    else if (case_num == 14) {
        // 大规模：全奇数次
        string s;
        for (int i = 0; i < 50000; i++) s += char('a' + i % 26);
        fout << s << "\n";
        fout << "50000\n";
    }
    else if (case_num == 15) {
        // 边界：刚好可以
        fout << "aabbccddee\n";
        fout << "1\n";
    }
    else if (case_num == 16) {
        fout << "aabbccdde\n";
        fout << "1\n";
    }
    else if (case_num == 17) {
        fout << "aabbccdde\n";
        fout << "2\n";
    }
    else if (case_num == 18) {
        // 长回文串
        fout << "abcddcba\n";
        fout << "1\n";
    }
    else if (case_num == 19) {
        fout << "abcddcba\n";
        fout << "4\n";
    }
    else if (case_num == 20) {
        fout << "abcddcba\n";
        fout << "8\n";
    }
    else if (case_num == 21) {
        // 多个奇数次字符
        fout << "aaabbbccc\n";
        fout << "3\n";
    }
    else if (case_num == 22) {
        fout << "aaabbbccc\n";
        fout << "2\n";
    }
    else if (case_num == 23) {
        // 恰好k个奇数次字符
        fout << "abcd\n";
        fout << "4\n";
    }
    else if (case_num == 24) {
        fout << "abcd\n";
        fout << "3\n";
    }
    else if (case_num == 25) {
        // 大规模边界
        string s(100000, 'a');
        fout << s << "\n";
        fout << "1\n";
    }
}

#endif
