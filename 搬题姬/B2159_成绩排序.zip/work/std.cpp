#include <bits/stdc++.h>
using namespace std;

struct Student {
    string name;
    int score;
};

// 比较函数：成绩降序，成绩相同按名字字典序升序
bool cmp(Student a, Student b) {
    if (a.score != b.score) return a.score > b.score;
    return a.name < b.name;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n;
    if (!(cin >> n)) return 0;
    
    vector<Student> stu(n);
    for (int i = 0; i < n; ++i) {
        cin >> stu[i].name >> stu[i].score;
    }
    
    sort(stu.begin(), stu.end(), cmp);
    
    for (int i = 0; i < n; ++i) {
        cout << stu[i].name << " " << stu[i].score << endl;
    }
    
    return 0;
}
