#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    string names[] = {"zhang", "li", "wang", "zhao", "liu", "chen", "yang", "huang", "zhou", "wu", 
                      "xu", "sun", "ma", "zhu", "hu", "guo", "he", "gao", "lin", "luo"};
    if (case_num == 1)
    {
        // 样例1
        fout << "4" << endl;
        fout << "abc 90" << endl;
        fout << "abd 90" << endl;
        fout << "abe 80" << endl;
        fout << "abf 100" << endl;
    }
    else if (case_num == 2)
    {
        // 样例2：1个学生
        fout << "1" << endl;
        fout << "xiaoming 95" << endl;
    }
    else if (case_num == 3)
    {
        // 小规模：全相同分数，按名字排序
        fout << "5" << endl;
        fout << "b 80" << endl;
        fout << "a 80" << endl;
        fout << "c 80" << endl;
        fout << "e 80" << endl;
        fout << "d 80" << endl;
    }
    else if (case_num == 4)
    {
        // 小规模：分数递减
        fout << "5" << endl;
        for(int i=0; i<5; i++) fout << names[i] << " " << (100 - i*5) << endl;
    }
    else if (case_num == 5)
    {
        // 小规模：分数递增
        fout << "5" << endl;
        for(int i=0; i<5; i++) fout << names[i+5] << " " << (60 + i*5) << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 中等规模：N=10~50
        int n = 10 + (case_num - 6) * 10;
        fout << n << endl;
        for(int i=0; i<n; i++) fout << names[i%20] << (i/20+1) << " " << (rand()%41 + 60) << endl;
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模：N=80，分数集中在 80-90
        int n = 80;
        fout << n << endl;
        for(int i=0; i<n; i++) fout << names[i%20] << "std" << i << " " << (80 + rand()%11) << endl;
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 大规模边界：N=100
        int n = 100;
        fout << n << endl;
        for(int i=0; i<n; i++) fout << names[i%20] << "big" << i << " " << (rand()%101) << endl;
    }
    else if (case_num >= 21 && case_num <= 25)
    {
        // 随机测试：N=1~100
        int n = rand()%100 + 1;
        fout << n << endl;
        for(int i=0; i<n; i++) fout << names[i%20] << "ran" << i << " " << (rand()%101) << endl;
    }
}

#endif
