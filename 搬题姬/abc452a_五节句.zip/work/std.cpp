#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int M, D;
    cin >> M >> D;

    // 判断是否是五节句之一
    // 1月7日、3月3日、5月5日、7月7日、9月9日
    if ((M == 1 && D == 7) ||
        (M == 3 && D == 3) ||
        (M == 5 && D == 5) ||
        (M == 7 && D == 7) ||
        (M == 9 && D == 9)) {
        cout << "Yes\n";
    } else {
        cout << "No\n";
    }

    return 0;
}
