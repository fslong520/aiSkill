#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout) {
    // 五节句: (1,7), (3,3), (5,5), (7,7), (9,9)

    if (case_num == 1) {
        // 样例1: 3 3 → Yes
        fout << "3 3" << endl;
    }
    else if (case_num == 2) {
        // 样例2: 1 1 → No
        fout << "1 1" << endl;
    }
    else if (case_num == 3) {
        // 样例3: 4 4 → No
        fout << "4 4" << endl;
    }
    else if (case_num == 4) {
        // 样例4: 11 7 → No
        fout << "11 7" << endl;
    }
    else if (case_num == 5) {
        // 五节句: 1月7日
        fout << "1 7" << endl;
    }
    else if (case_num == 6) {
        // 五节句: 5月5日
        fout << "5 5" << endl;
    }
    else if (case_num == 7) {
        // 五节句: 7月7日
        fout << "7 7" << endl;
    }
    else if (case_num == 8) {
        // 五节句: 9月9日
        fout << "9 9" << endl;
    }
    else if (case_num == 9) {
        // 非五节句: 2月14日
        fout << "2 14" << endl;
    }
    else if (case_num == 10) {
        // 非五节句: 12月25日
        fout << "12 25" << endl;
    }
    else if (case_num == 11) {
        // 边界: 1月31日
        fout << "1 31" << endl;
    }
    else if (case_num == 12) {
        // 边界: 12月31日
        fout << "12 31" << endl;
    }
    else if (case_num == 13) {
        // 闰年2月29日
        fout << "2 29" << endl;
    }
    else if (case_num == 14) {
        // 容易混淆: 7月1日(不是7月7日)
        fout << "7 1" << endl;
    }
    else if (case_num == 15) {
        // 容易混淆: 9月7日(不是9月9日)
        fout << "9 7" << endl;
    }
    else if (case_num == 16) {
        // 容易混淆: 3月7日(不是3月3日)
        fout << "3 7" << endl;
    }
    else if (case_num == 17) {
        // 容易混淆: 5月7日(不是5月5日)
        fout << "5 7" << endl;
    }
    else if (case_num == 18) {
        // 容易混淆: 1月3日(不是1月7日)
        fout << "1 3" << endl;
    }
    else if (case_num == 19) {
        // 非五节句: 6月1日
        fout << "6 1" << endl;
    }
    else if (case_num == 20) {
        // 非五节句: 8月15日
        fout << "8 15" << endl;
    }
    else if (case_num == 21) {
        // 非五节句: 10月1日
        fout << "10 1" << endl;
    }
    else if (case_num == 22) {
        // 非五节句: 11月11日
        fout << "11 11" << endl;
    }
    else if (case_num == 23) {
        // 非五节句: 4月30日
        fout << "4 30" << endl;
    }
    else if (case_num == 24) {
        // 非五节句: 6月30日
        fout << "6 30" << endl;
    }
    else if (case_num == 25) {
        // 非五节句: 8月8日
        fout << "8 8" << endl;
    }
}

#endif
