#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    long long k;
    cin >> n >> k;

    vector<long long> d(n);
    for (int i = 0; i < n; i++) {
        cin >> d[i];
    }

    // 对 d 排序，方便计算
    sort(d.begin(), d.end());

    // 代价函数：给定起始日 s，计算最小总不满度
    // 对于每个 D_i，如果 D_i < s，则必须在 s 天送，代价为 s - D_i
    // 如果 D_i > s+K-1，则必须在 s+K-1 天送，代价为 D_i - (s+K-1)
    // 如果 s <= D_i <= s+K-1，则可以在 D_i 天送，代价为 0
    auto calc = [&](long long s) -> long long {
        long long cost = 0;
        for (int i = 0; i < n; i++) {
            if (d[i] < s) {
                cost += s - d[i];
            } else if (d[i] > s + k - 1) {
                cost += d[i] - (s + k - 1);
            }
        }
        return cost;
    };

    // 三分查找最优 s
    // 代价函数是单峰的（凸函数）
    long long lo = -2000000000LL, hi = 2000000000LL;
    while (hi - lo > 2) {
        long long m1 = lo + (hi - lo) / 3;
        long long m2 = hi - (hi - lo) / 3;
        if (calc(m1) <= calc(m2)) {
            hi = m2;
        } else {
            lo = m1;
        }
    }

    long long ans = 1e18;
    for (long long s = lo; s <= hi; s++) {
        ans = min(ans, calc(s));
    }

    cout << ans << "\n";

    return 0;
}
