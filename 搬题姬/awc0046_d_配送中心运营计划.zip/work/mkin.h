#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        // 样例1
        fout << "5 3" << endl;
        fout << "1 2 3 4 5" << endl;
    }
    else if (case_num == 2)
    {
        // 样例2
        fout << "4 10" << endl;
        fout << "5 8 12 20" << endl;
    }
    else if (case_num == 3)
    {
        // 样例3
        fout << "7 5" << endl;
        fout << "100 102 105 110 115 118 120" << endl;
    }
    else if (case_num == 4)
    {
        // N=1
        fout << "1 1" << endl;
        fout << "100" << endl;
    }
    else if (case_num == 5)
    {
        // K=1，所有 D_i 相同
        fout << "3 1" << endl;
        fout << "10 10 10" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 小规模测试：N=10~50
        int n = 10 + (case_num - 6) * 10;
        long long k = rand() % 20 + 1;
        fout << n << " " << k << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 100 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模测试：N=100~1000
        int n = 100 + (case_num - 11) * 225;
        long long k = rand() % 100 + 10;
        fout << n << " " << k << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 10000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 大规模测试：N=10000~100000
        int n = 10000 + (case_num - 16) * 22500;
        long long k = rand() % 100000 + 100;
        fout << n << " " << k << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 21)
    {
        // 边界：K=1，N=200000
        int n = 200000;
        fout << n << " 1" << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 22)
    {
        // 边界：K=10^9，很大
        int n = 1000;
        fout << n << " 1000000000" << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 23)
    {
        // 边界：D_i 很大
        int n = 50000;
        fout << n << " 1" << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 24)
    {
        // 最大规模：N=200000
        int n = 200000;
        long long k = rand() % 1000000000 + 1;
        fout << n << " " << k << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else
    {
        // 随机压力测试
        int n = rand() % 100000 + 1;
        long long k = rand() % 1000000000 + 1;
        fout << n << " " << k << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
}

#endif
