#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        fout << "5 3" << endl;
        fout << "7 2 5 10 8" << endl;
    }
    else if (case_num == 2)
    {
        // m=n, 每段一个元素
        fout << "5 5" << endl;
        fout << "7 2 5 10 8" << endl;
    }
    else if (case_num == 3)
    {
        // m=1, 全部一段
        fout << "5 1" << endl;
        fout << "7 2 5 10 8" << endl;
    }
    else if (case_num == 4)
    {
        // 全0
        fout << "5 3" << endl;
        fout << "0 0 0 0 0" << endl;
    }
    else if (case_num == 5)
    {
        // 全相同
        fout << "6 3" << endl;
        fout << "5 5 5 5 5 5" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 小规模
        int n = 5 + (case_num - 6) * 3;
        int m = rand() % (n - 1) + 2;
        fout << n << " " << m << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 100 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模
        int n = 100 + (case_num - 11) * 200;
        int m = rand() % (n / 2) + 1;
        fout << n << " " << m << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 10000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 大规模
        int n = 1000 + (case_num - 16) * 24750;
        int m = rand() % (n / 10) + 1;
        fout << n << " " << m << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 21)
    {
        // 递增序列
        int n = 100, m = 10;
        fout << n << " " << m << endl;
        for (int i = 0; i < n; i++) {
            fout << (i + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 22)
    {
        // 一个超大元素
        int n = 100, m = 10;
        fout << n << " " << m << endl;
        for (int i = 0; i < n; i++) {
            if (i == n / 2) fout << "1000000000";
            else fout << "1";
            fout << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 23)
    {
        // n=100000, m=1
        int n = 100000;
        fout << n << " 1" << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 24)
    {
        // n=100000, m=100000
        int n = 100000;
        fout << n << " " << n << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else
    {
        int n = rand() % 50000 + 1;
        int m = rand() % n + 1;
        fout << n << " " << m << endl;
        for (int i = 0; i < n; i++) {
            fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
}

#endif
