#include <bits/stdc++.h>
using namespace std;

const int N = 100005;
int n, m;
long long a[N];

bool check(long long x) {
    int cnt = 1;
    long long sum = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] > x) return false;
        if (sum + a[i] > x) {
            cnt++;
            sum = a[i];
        } else {
            sum += a[i];
        }
    }
    return cnt <= m;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    cin >> n >> m;
    long long left = 0, right = 0;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        left = max(left, a[i]);
        right += a[i];
    }
    
    while (left < right) {
        long long mid = left + (right - left) / 2;
        if (check(mid)) {
            right = mid;
        } else {
            left = mid + 1;
        }
    }
    
    cout << left << '\n';
    
    return 0;
}
