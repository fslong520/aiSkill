#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        fout << "4 2" << endl;
        fout << "3 -2 4 -1" << endl;
        fout << "2 5" << endl;
    }
    else if (case_num == 2)
    {
        fout << "5 0" << endl;
        fout << "-3 1 2 -1 4" << endl;
    }
    else if (case_num == 3)
    {
        fout << "10 6" << endl;
        fout << "2 5 -3 6 -4 7 -8 3 4 -2" << endl;
        fout << "-7 8 14 19 -11 25" << endl;
    }
    else if (case_num == 4)
    {
        fout << "20 15" << endl;
        fout << "5 4 -6 7 -3 8 -10 6 9 -5 4 -7 12 -8 3 11 -9 2 6 -4" << endl;
        fout << "-20 -13 -1 10 18 27 35 44 -7 5 14 22 31 40 50" << endl;
    }
    else if (case_num == 5)
    {
        fout << "1 1" << endl;
        fout << "50000" << endl;
        fout << "0" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        int n = 10 + (case_num - 6) * 10;
        int m = rand() % 6;
        fout << n << " " << m << endl;
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int v = rand() % 10 + 1;
            if (rand() % 2 == 0) v = -v;
            if (sum + abs(v) > 50000) v = 1;
            sum += abs(v);
            fout << v << (i == n - 1 ? "" : " ");
        }
        fout << endl;
        for (int i = 0; i < m; i++) {
            fout << (rand() % 200 - 100) << (i == m - 1 ? "" : " ");
        }
        if (m > 0) fout << endl;
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        int n = 100 + (case_num - 11) * 225;
        int m = rand() % 50 + 10;
        fout << n << " " << m << endl;
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int v = rand() % 50 + 1;
            if (rand() % 2 == 0) v = -v;
            if (sum + abs(v) > 50000) v = (rand() % 3 + 1) * (rand() % 2 == 0 ? 1 : -1);
            sum += abs(v);
            fout << v << (i == n - 1 ? "" : " ");
        }
        fout << endl;
        for (int i = 0; i < m; i++) {
            fout << (rand() % 400 - 200) << (i == m - 1 ? "" : " ");
        }
        if (m > 0) fout << endl;
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        int n = 10000 + (case_num - 16) * 10000;
        int m = rand() % 200 + 50;
        fout << n << " " << m << endl;
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int v = rand() % 5 + 1;
            if (rand() % 2 == 0) v = -v;
            if (sum + abs(v) > 50000) v = 1;
            sum += abs(v);
            fout << v << (i == n - 1 ? "" : " ");
        }
        fout << endl;
        for (int i = 0; i < m; i++) {
            fout << (rand() % 1000 - 500) << (i == m - 1 ? "" : " ");
        }
        if (m > 0) fout << endl;
    }
    else if (case_num == 21)
    {
        int n = 1000;
        int m = 0;
        fout << n << " " << m << endl;
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int v = rand() % 10 + 1;
            if (rand() % 2 == 0) v = -v;
            if (sum + abs(v) > 50000) v = 1;
            sum += abs(v);
            fout << v << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 22)
    {
        int n = 500;
        int m = 200;
        fout << n << " " << m << endl;
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int v = rand() % 20 + 1;
            if (rand() % 2 == 0) v = -v;
            if (sum + abs(v) > 50000) v = 1;
            sum += abs(v);
            fout << v << (i == n - 1 ? "" : " ");
        }
        fout << endl;
        for (int i = 0; i < m; i++) {
            fout << (i * 2 - m) << (i == m - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 23)
    {
        int n = 5000;
        int m = 100;
        fout << n << " " << m << endl;
        for (int i = 0; i < n; i++) {
            fout << "1" << (i == n - 1 ? "" : " ");
        }
        fout << endl;
        for (int i = 0; i < m; i++) {
            fout << (rand() % 5000 + 1) << (i == m - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 24)
    {
        int n = 50000;
        int m = 5000;
        fout << n << " " << m << endl;
        for (int i = 0; i < n; i++) {
            fout << ((i % 2 == 0) ? "1" : "-1") << (i == n - 1 ? "" : " ");
        }
        fout << endl;
        for (int i = 0; i < m; i++) {
            fout << (i * 10 - m * 5) << (i == m - 1 ? "" : " ");
        }
        fout << endl;
    }
    else
    {
        int n = rand() % 10000 + 1;
        int m = rand() % 1000;
        fout << n << " " << m << endl;
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int v = rand() % 10 + 1;
            if (rand() % 2 == 0) v = -v;
            if (sum + abs(v) > 50000) v = 1;
            sum += abs(v);
            fout << v << (i == n - 1 ? "" : " ");
        }
        fout << endl;
        for (int i = 0; i < m; i++) {
            fout << (rand() % 10000 - 5000) << (i == m - 1 ? "" : " ");
        }
        if (m > 0) fout << endl;
    }
}

#endif
