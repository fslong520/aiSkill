#include <bits/stdc++.h>
using namespace std;

static const int MAXS = 50000;
static const int SZ = MAXS * 2 + 1;
static const int OFF = MAXS;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    cin >> N >> M;

    vector<int> D(N);
    for (int i = 0; i < N; i++) cin >> D[i];

    vector<long long> X(M);
    for (int i = 0; i < M; i++) cin >> X[i];

    sort(X.begin(), X.end());

    // 如果 0 本身是路障，任何移动都无法执行
    if (binary_search(X.begin(), X.end(), 0LL)) {
        cout << 0 << '\n';
        return 0;
    }

    long long L = -(1LL << 60), R = (1LL << 60);

    auto it = lower_bound(X.begin(), X.end(), 0LL);
    if (it != X.end()) R = *it;          // 右边最近路障
    if (it != X.begin()) {
        --it;
        L = *it;                         // 左边最近路障
    }

    // valid[pos + OFF] = 1 表示该坐标合法（可站立）
    bitset<SZ> valid, dp, shifted;

    for (int x = -MAXS; x <= MAXS; x++) {
        if ((long long)x > L && (long long)x < R) {
            valid.set(x + OFF);
        }
    }

    dp.reset();
    dp.set(OFF); // 起点 0

    for (int d : D) {
        if (d > 0) shifted = (dp << d);
        else shifted = (dp >> (-d));

        shifted &= valid; // 执行该计划后，终点必须仍在合法区间内
        dp |= shifted;    // 可执行也可跳过
    }

    for (int x = MAXS; x >= -MAXS; x--) {
        if (dp.test(x + OFF)) {
            cout << x << '\n';
            return 0;
        }
    }

    return 0;
}
