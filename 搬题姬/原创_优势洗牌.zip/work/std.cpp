#include <bits/stdc++.h>
using namespace std;

const int N = 100005;
int n, a[N], b[N], ans[N];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    cin >> n;
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 0; i < n; i++) cin >> b[i];
    
    sort(a, a + n);
    
    vector<pair<int, int>> sb(n);
    for (int i = 0; i < n; i++) sb[i] = {b[i], i};
    sort(sb.begin(), sb.end());
    
    int left = 0, right = n - 1;
    for (int i = n - 1; i >= 0; i--) {
        if (a[right] > sb[i].first) {
            ans[sb[i].second] = a[right];
            right--;
        } else {
            ans[sb[i].second] = a[left];
            left++;
        }
    }
    
    for (int i = 0; i < n; i++) {
        cout << ans[i] << (i == n - 1 ? "" : " ");
    }
    cout << '\n';
    
    return 0;
}
