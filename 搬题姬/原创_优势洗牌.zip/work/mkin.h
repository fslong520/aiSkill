#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        fout << "5" << endl;
        fout << "2 7 11 15 20" << endl;
        fout << "1 10 4 11 20" << endl;
    }
    else if (case_num == 2)
    {
        // n=1
        fout << "1" << endl;
        fout << "5" << endl;
        fout << "3" << endl;
    }
    else if (case_num == 3)
    {
        // 完全相同
        fout << "3" << endl;
        fout << "1 2 3" << endl;
        fout << "1 2 3" << endl;
    }
    else if (case_num == 4)
    {
        // A 全大于 B
        fout << "3" << endl;
        fout << "10 20 30" << endl;
        fout << "1 2 3" << endl;
    }
    else if (case_num == 5)
    {
        // A 全小于 B
        fout << "3" << endl;
        fout << "1 2 3" << endl;
        fout << "10 20 30" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        int n = 5 + (case_num - 6) * 5;
        fout << n << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 100 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 100 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        int n = 100 + (case_num - 11) * 200;
        fout << n << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 10000 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 10000 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        int n = 1000 + (case_num - 16) * 24750;
        fout << n << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
    }
    else if (case_num == 21)
    {
        // 全相同元素
        int n = 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) fout << "5" << (i == n - 1 ? "" : " ");
        fout << endl;
        for (int i = 0; i < n; i++) fout << "5" << (i == n - 1 ? "" : " ");
        fout << endl;
    }
    else if (case_num == 22)
    {
        // A 和 B 完全一样
        int n = 100;
        fout << n << endl;
        for (int i = 0; i < n; i++) {
            int v = rand() % 1000 + 1;
            fout << v << (i == n - 1 ? "" : " ");
        }
        fout << endl;
        for (int i = 0; i < n; i++) {
            int v = rand() % 1000 + 1;
            fout << v << (i == n - 1 ? "" : " ");
        }
        fout << endl;
    }
    else if (case_num == 23)
    {
        // n=100000
        int n = 100000;
        fout << n << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
    }
    else if (case_num == 24)
    {
        // 包含0
        fout << "5" << endl;
        fout << "0 0 0 0 0" << endl;
        fout << "0 0 0 0 0" << endl;
    }
    else
    {
        int n = rand() % 50000 + 1;
        fout << n << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
        for (int i = 0; i < n; i++) fout << (rand() % 1000000000 + 1) << (i == n - 1 ? "" : " ");
        fout << endl;
    }
}

#endif
