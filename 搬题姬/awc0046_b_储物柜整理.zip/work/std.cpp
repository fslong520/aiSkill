#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    unsigned long long n;
    cin >> n;

    // 整数开方，避免 double 精度丢失
    unsigned long long lo = 0, hi = 2000000000ULL;
    while (lo < hi) {
        unsigned long long mid = (lo + hi + 1) / 2;
        if (mid * mid <= n) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }

    cout << lo << "\n";

    return 0;
}
