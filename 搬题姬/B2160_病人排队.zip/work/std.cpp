#include <bits/stdc++.h>
using namespace std;

struct Patient {
    string id;
    int age;
    int order; // 登记顺序
};

// 比较函数
bool cmp(Patient a, Patient b) {
    bool a_old = (a.age >= 60);
    bool b_old = (b.age >= 60);
    
    if (a_old != b_old) {
        return a_old > b_old; // 老年人优先
    }
    
    if (a_old && b_old) {
        // 都是老年人：按年龄降序，年龄相同按登记顺序升序
        if (a.age != b.age) return a.age > b.age;
        return a.order < b.order;
    }
    
    // 都是非老年人：按登记顺序升序
    return a.order < b.order;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n;
    if (!(cin >> n)) return 0;
    
    vector<Patient> p(n);
    for (int i = 0; i < n; ++i) {
        cin >> p[i].id >> p[i].age;
        p[i].order = i;
    }
    
    sort(p.begin(), p.end(), cmp);
    
    for (int i = 0; i < n; ++i) {
        cout << p[i].id << endl;
    }
    
    return 0;
}
