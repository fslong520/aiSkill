#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout)
{
    if (case_num == 1)
    {
        // 样例1
        fout << "5" << endl;
        fout << "001 65" << endl;
        fout << "002 20" << endl;
        fout << "003 70" << endl;
        fout << "004 60" << endl;
        fout << "005 20" << endl;
    }
    else if (case_num == 2)
    {
        // 样例2：全老年人
        fout << "3" << endl;
        fout << "A 70" << endl;
        fout << "B 70" << endl;
        fout << "C 80" << endl;
    }
    else if (case_num == 3)
    {
        // 样例3：全非老年人
        fout << "3" << endl;
        fout << "X 20" << endl;
        fout << "Y 30" << endl;
        fout << "Z 10" << endl;
    }
    else if (case_num == 4)
    {
        // 边界：年龄刚好60
        fout << "2" << endl;
        fout << "old 60" << endl;
        fout << "young 59" << endl;
    }
    else if (case_num == 5)
    {
        // 小规模：混合，老人年龄相同
        fout << "4" << endl;
        fout << "p1 65" << endl;
        fout << "p2 65" << endl;
        fout << "p3 20" << endl;
        fout << "p4 20" << endl;
    }
    else if (case_num >= 6 && case_num <= 10)
    {
        // 中等规模：N=10~50
        int n = 10 + (case_num - 6) * 10;
        fout << n << endl;
        for(int i=0; i<n; i++) fout << "id" << i << " " << (rand()%81 + 20) << endl; // 20~100
    }
    else if (case_num >= 11 && case_num <= 15)
    {
        // 中等规模：N=80，大量同龄老人
        int n = 80;
        fout << n << endl;
        for(int i=0; i<n; i++) fout << "p" << i << " " << (60 + rand()%5) << endl;
    }
    else if (case_num >= 16 && case_num <= 20)
    {
        // 大规模边界：N=100
        int n = 100;
        fout << n << endl;
        for(int i=0; i<n; i++) fout << "pat" << i << " " << (rand()%101) << endl;
    }
    else if (case_num >= 21 && case_num <= 25)
    {
        // 随机测试：N=1~100
        int n = rand()%100 + 1;
        fout << n << endl;
        for(int i=0; i<n; i++) fout << "r" << i << " " << (rand()%101) << endl;
    }
}

#endif
