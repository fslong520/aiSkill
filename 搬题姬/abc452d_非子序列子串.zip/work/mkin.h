#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout) {
    // 生成各种规模的测试数据

    if (case_num == 1) {
        // 样例1
        fout << "abrakadabra\n";
        fout << "aba\n";
    }
    else if (case_num == 2) {
        // 样例2
        fout << "aaaaa\n";
        fout << "a\n";
    }
    else if (case_num == 3) {
        // 样例3
        fout << "rdddrdtdcdrrdcredctdordoeecrotet\n";
        fout << "dcre\n";
    }
    else if (case_num == 4) {
        // 最小数据
        fout << "a\n";
        fout << "a\n";
    }
    else if (case_num == 5) {
        // 最小数据，不匹配
        fout << "a\n";
        fout << "b\n";
    }
    else if (case_num == 6) {
        // S 长度为 2
        fout << "ab\n";
        fout << "a\n";
    }
    else if (case_num == 7) {
        // T 长度为 1
        fout << "abcdef\n";
        fout << "c\n";
    }
    else if (case_num == 8) {
        // T 长度为 1，不出现
        fout << "abcdef\n";
        fout << "z\n";
    }
    else if (case_num == 9) {
        // 全相同字符
        fout << "aaaaaa\n";
        fout << "aa\n";
    }
    else if (case_num == 10) {
        // T 比 S 长
        fout << "abc\n";
        fout << "abcdef\n";
    }
    else if (case_num == 11) {
        // 边界测试
        fout << "abcde\n";
        fout << "abcde\n";
    }
    else if (case_num == 12) {
        // 部分匹配
        fout << "abababab\n";
        fout << "ab\n";
    }
    else if (case_num == 13) {
        // 不匹配
        fout << "xyzxyz\n";
        fout << "abc\n";
    }
    else if (case_num == 14) {
        // 单字符 T
        fout << "abcdefghijklmnopqrstuvwxyz\n";
        fout << "m\n";
    }
    else if (case_num == 15) {
        // T 长度为 50
        fout << "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwx\n";
        fout << "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwx\n";
    }
    else if (case_num == 16) {
        fout << "hello\n";
        fout << "lo\n";
    }
    else if (case_num == 17) {
        fout << "world\n";
        fout << "od\n";
    }
    else if (case_num == 18) {
        fout << "abacaba\n";
        fout << "aba\n";
    }
    else if (case_num == 19) {
        fout << "aaaabbbb\n";
        fout << "ab\n";
    }
    else if (case_num == 20) {
        fout << "xxyyzz\n";
        fout << "xyz\n";
    }
    else if (case_num == 21) {
        // 中等规模
        fout << "abcdefghijabcdefghij\n";
        fout << "aei\n";
    }
    else if (case_num == 22) {
        fout << "abcdabcdabcd\n";
        fout << "ac\n";
    }
    else if (case_num == 23) {
        fout << "zzzzzzzz\n";
        fout << "zzz\n";
    }
    else if (case_num == 24) {
        fout << "abcabcabc\n";
        fout << "abcabcabc\n";
    }
    else if (case_num == 25) {
        // 较大规模
        string s;
        for (int i = 0; i < 100; i++) s += "ab";
        fout << s << "\n";
        fout << "aba\n";
    }
}

#endif
