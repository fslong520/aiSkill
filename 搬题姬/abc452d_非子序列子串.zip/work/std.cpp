#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string S, T;
    cin >> S >> T;
    int n = S.size(), m = T.size();

    // 预处理：next_pos[i][c] 表示从位置 i（含）开始，字符 c 最早出现的位置
    vector<vector<int>> next_pos(n + 1, vector<int>(26, n));
    for (int i = n - 1; i >= 0; i--) {
        for (int c = 0; c < 26; c++) {
            next_pos[i][c] = next_pos[i + 1][c];
        }
        next_pos[i][S[i] - 'a'] = i;
    }

    long long ans = 0;

    // 对于每个左端点 l，找到使得 S[l..r] 刚好包含 T 作为子序列的最小 r
    // 则 S[l..l], S[l..l+1], ..., S[l..r-1] 都是不包含 T 的子串
    for (int l = 0; l < n; l++) {
        int pos = l;  // 当前在 S 中匹配到的位置
        bool found = true;

        for (int j = 0; j < m; j++) {
            pos = next_pos[pos][T[j] - 'a'];
            if (pos == n) {
                // 找不到 T[j]
                found = false;
                break;
            }
            pos++; // 移动到下一个位置继续找 T[j+1]
        }

        if (!found) {
            // 从 l 开始的所有子串都不包含 T
            ans += n - l;
        } else {
            // S[l..pos-1] 是包含 T 的最短子串
            // 长度为 1 到 pos-1-l 的子串都不包含 T
            ans += pos - 1 - l;
        }
    }

    cout << ans << "\n";

    return 0;
}
