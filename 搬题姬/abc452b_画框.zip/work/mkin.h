#pragma once

#ifndef MKIN_H
#define MKIN_H

#include <bits/stdc++.h>
using namespace std;

const int TEST_CASES = 25;

void test(int case_num, ofstream& fout) {
    // 数据范围: 3 <= H, W <= 10

    if (case_num == 1) {
        // 样例1: 4 5
        fout << "4 5" << endl;
    }
    else if (case_num == 2) {
        // 样例2: 5 6
        fout << "5 6" << endl;
    }
    else if (case_num == 3) {
        // 边界: 最小网格 3 3
        fout << "3 3" << endl;
    }
    else if (case_num == 4) {
        // 边界: 最大网格 10 10
        fout << "10 10" << endl;
    }
    else if (case_num == 5) {
        // 边界: 最小H，最大W
        fout << "3 10" << endl;
    }
    else if (case_num == 6) {
        // 边界: 最大H，最小W
        fout << "10 3" << endl;
    }
    else if (case_num == 7) {
        // 正方形网格
        fout << "5 5" << endl;
    }
    else if (case_num == 8) {
        // 正方形网格
        fout << "7 7" << endl;
    }
    else if (case_num == 9) {
        // 扁平网格
        fout << "3 8" << endl;
    }
    else if (case_num == 10) {
        // 窄长网格
        fout << "8 3" << endl;
    }
    else if (case_num == 11) {
        fout << "4 4" << endl;
    }
    else if (case_num == 12) {
        fout << "6 6" << endl;
    }
    else if (case_num == 13) {
        fout << "8 8" << endl;
    }
    else if (case_num == 14) {
        fout << "9 9" << endl;
    }
    else if (case_num == 15) {
        fout << "4 7" << endl;
    }
    else if (case_num == 16) {
        fout << "7 4" << endl;
    }
    else if (case_num == 17) {
        fout << "5 9" << endl;
    }
    else if (case_num == 18) {
        fout << "9 5" << endl;
    }
    else if (case_num == 19) {
        fout << "6 8" << endl;
    }
    else if (case_num == 20) {
        fout << "8 6" << endl;
    }
    else if (case_num == 21) {
        fout << "4 9" << endl;
    }
    else if (case_num == 22) {
        fout << "9 4" << endl;
    }
    else if (case_num == 23) {
        fout << "3 5" << endl;
    }
    else if (case_num == 24) {
        fout << "5 3" << endl;
    }
    else if (case_num == 25) {
        fout << "6 9" << endl;
    }
}

#endif
