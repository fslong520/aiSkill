#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int H, W;
    cin >> H >> W;

    for (int i = 0; i < H; i++) {
        for (int j = 0; j < W; j++) {
            // 边界条件：第一行、最后一行、第一列、最后一列
            if (i == 0 || i == H - 1 || j == 0 || j == W - 1) {
                cout << '#';
            } else {
                cout << '.';
            }
        }
        cout << '\n';
    }

    return 0;
}
