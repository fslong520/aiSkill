#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;

    vector<int> s(n);
    for (int i = 0; i < n; i++) {
        cin >> s[i];
    }

    int ans = 0;
    for (int i = 0; i < n; i++) {
        if (s[i] == 1) continue;

        // 尝试坐人，检查坐下后是否会产生连续3个1
        bool ok = true;

        // 检查 i-2, i-1, i
        if (i >= 2 && s[i - 2] == 1 && s[i - 1] == 1) ok = false;
        // 检查 i-1, i, i+1
        if (i >= 1 && i < n - 1 && s[i - 1] == 1 && s[i + 1] == 1) ok = false;
        // 检查 i, i+1, i+2
        if (i < n - 2 && s[i + 1] == 1 && s[i + 2] == 1) ok = false;

        if (!ok) continue;

        ans++;
        s[i] = 1;
    }

    cout << ans << "\n";

    return 0;
}
